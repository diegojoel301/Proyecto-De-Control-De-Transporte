package com.example.proyecto_lab_131;

import java.io.Serializable;

public class MultiPM implements Serializable
{
    private PilaM v[] = new PilaM[20];
    private int n;

    MultiPM()
    {
        for(int i = 0; i < 20; i++)
            v[i] = new PilaM();
    }

    public int getN()
    {
        return n;
    }

    public void setN(int n)
    {
        this.n = n;
    }

    public boolean esVacia(int i)
    {
        return v[i].esVacia();
    }

    public boolean esLlena(int i)
    {
        return v[i].esLlena();
    }

    public void adicionar(int i, Minibus x)
    {
        v[i].adicionar(x);
    }

    public Minibus eliminar(int i)
    {
        return v[i].eliminar();
    }
    public void vaciar(int i, int j)
    {
        v[i].vaciar(v[j]);
    }
    public void vaciar(int i, PilaM Z)
    {
        v[i].vaciar(Z);
    }
}
