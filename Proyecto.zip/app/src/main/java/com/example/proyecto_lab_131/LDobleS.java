package com.example.proyecto_lab_131;

import java.io.Serializable;

public class LDobleS implements Serializable
{
    private NodoS p;

    LDobleS()
    {
        p = null;
    }

    public NodoS getP()
    {
        return p;
    }

    public void setP(NodoS p)
    {
        this.p = p;
    }

    public void adicionar(String x,int y, LDCircularOD z) //adicionado al final
    {
        NodoS nue = new NodoS();

        nue.setSindicato(x);
        nue.setTipoVehiculos(y);
        nue.setA(z);

        if(getP() == null)
            setP(nue);
        else
        {
            /*
            getP().setAnt(nue);
            nue.setSig(getP());
            setP(nue);*/
            NodoS w = getP();

            while(w.getSig() != null)
                w = w.getSig();
            w.setSig(nue);
            nue.setAnt(w);

        }
    }
/*
    public int nroNodos()
    {
        int c = 0;
        NodoS w = getP();
        while(w != null)
        {
            c++;
            w = w.getSig();
        }
        return c;
    }
*/
    public void mostrar()
    {
        NodoS w = getP();

        while(w != null)
        {
            System.out.println(w.getSindicato() + " " + w.getTipoVehiculos());
            if(w.getA().getP() != null)
                w.getA().mostrar();
            w = w.getSig();
        }
    }
}
