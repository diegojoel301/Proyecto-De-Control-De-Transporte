package com.example.proyecto_lab_131;

import java.io.Serializable;

public class MultiCCT implements Serializable
{
    private CCircularT v[] = new CCircularT[20];
    private int n;

    MultiCCT()
    {
        for(int i = 0; i < 20; i++)
            v[i] = new CCircularT();
    }

    public int getN()
    {
        return n;
    }

    public void setN(int n)
    {
        this.n = n;
    }

    public boolean esVacia(int i)
    {
        return v[i].esVacia();
    }

    public int nroElementos(int i){ return v[i].nroElementos(); }

    public boolean esLlena(int i)
    {
        return v[i].esLlena();
    }

    public void adicionar(int i, Trufi x)
    {
        v[i].adicionar(x);
    }

    public Trufi eliminar(int i)
    {
        return v[i].eliminar();
    }
    public void vaciar(int i, int j)
    {
        v[i].vaciar(v[j]);
    }
    public void vaciar(int i, CCircularT Z)
    {
        v[i].vaciar(Z);
    }
}
