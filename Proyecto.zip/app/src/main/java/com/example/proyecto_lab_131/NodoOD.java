package com.example.proyecto_lab_131;

import java.io.Serializable;

public class NodoOD implements Serializable
{
    private String origen, destino;
    private NodoOD ant, sig;
    private int pasaje;

    NodoOD()
    {
        ant = sig = null;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public NodoOD getAnt() {
        return ant;
    }

    public void setAnt(NodoOD ant) {
        this.ant = ant;
    }

    public NodoOD getSig() {
        return sig;
    }

    public void setSig(NodoOD sig) {
        this.sig = sig;
    }

    public int getPasaje() { return pasaje; }

    public void setPasaje(int pasaje) { this.pasaje = pasaje; }
}
