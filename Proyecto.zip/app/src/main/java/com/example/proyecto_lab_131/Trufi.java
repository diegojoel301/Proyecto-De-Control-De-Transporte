package com.example.proyecto_lab_131;

import java.io.Serializable;

public class Trufi extends Vehiculo implements Serializable
{
    public Trufi(String marca, String placa, int modelo) {
        super(marca, placa, modelo);
    }
}
