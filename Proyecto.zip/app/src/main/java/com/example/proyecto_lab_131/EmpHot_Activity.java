package com.example.proyecto_lab_131;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompatSideChannelService;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class EmpHot_Activity extends AppCompatActivity {

    private TableLayout tab1;
    private int tipoVehiculo, pos, posicion;
    private CSimpleRT colaRadioTaxis = new CSimpleRT();
    private PilaT pilaTaxis = new PilaT();
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_hot);

        tab1 = (TableLayout)findViewById(R.id.tableVehiculo);
        pilaTaxis = (PilaT) getIntent().getSerializableExtra("multi");
        colaRadioTaxis = (CSimpleRT) getIntent().getSerializableExtra("multi1");

        pos = getIntent().getIntExtra("posicion", -1);
        posicion = getIntent().getIntExtra("posicionLista", -1);
        tipoVehiculo = getIntent().getIntExtra("tipoVehiculo", - 1);

        if(tipoVehiculo == 1)
        {
            agregacionTaxis();
        }
        else
        {
            agregacionRadioTaxis();
        }
    }
    public void limpieza()
    {
        int nro = tab1.getChildCount();

        for(int i = 2; i < nro; i++)
            tab1.removeViewAt(1);
        sendDialogDataToActivity("", "", "", "", "", "", false);
        sendDialogDataToActivity("", "", "", "", "", "", false);
    }
    public void agregacionTaxis()
    {
        PilaT aux = new PilaT();

        while(!pilaTaxis.esVacia())
        {
            Taxi x = pilaTaxis.eliminar();
            sendDialogDataToActivity(x.getMarca(), x.getPlaca(), x.getModelo() + "", x.getOrigen(), x.getDestino(), x.getPasaje() +"", true);
            sendDialogDataToActivity("", "", "", "", "", "", false);
            sendDialogDataToActivity("", "", "", "", "", "", false);
            sendDialogDataToActivity("", "", "", "", "", "", false);
            aux.adicionar(x);
        }
        pilaTaxis.vaciar(aux);
    }
    public void agregacionRadioTaxis()
    {
        CSimpleRT aux = new CSimpleRT();

        while(!colaRadioTaxis.esVacia())
        {
            RadioTaxi x = colaRadioTaxis.eliminar();
            sendDialogDataToActivity(x.getMarca(), x.getPlaca(), x.getModelo() + "", x.getOrigen(), x.getDestino(), x.getPasaje() +"", true);
            sendDialogDataToActivity("", "", "", "", "", "", false);
            sendDialogDataToActivity("", "", "", "", "", "", false);
            sendDialogDataToActivity("", "", "", "", "", "", false);
            aux.adicionar(x);
        }
        colaRadioTaxis.vaciar(aux);
    }
    @Override
    protected void onPause()
    { //debemos hacer que se pause la aplicacion y sea null nuestro objeto posterior a este proceso se prodecede a la serializacion de deicho objeto
        super.onPause();
        //obj = null; // temporal
        //nodeOriginDestiny = null;
        colaRadioTaxis = null;
        pilaTaxis = null;
    }
    public void adicionarVehiculo(View view)
    {
        // create an alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Agragacion de Vehiculo");

        // set the custom layout
        final View customLayout = getLayoutInflater().inflate(R.layout.agregacion_vehiculo_emphot, null);
        builder.setView(customLayout);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // send data from the AlertDialog to the Activity

                EditText marca = customLayout.findViewById(R.id.editText1);
                EditText placa = customLayout.findViewById(R.id.editText2);
                EditText modelo = customLayout.findViewById(R.id.editTextNumber);

                EditText origen = customLayout.findViewById(R.id.editText3);
                EditText destino = customLayout.findViewById(R.id.editText4);
                EditText pasaje = customLayout.findViewById(R.id.editTextNumber1);

                if(tipoVehiculo == 1)
                {
                    pilaTaxis.adicionar(new Taxi(marca.getText().toString(), placa.getText().toString(), Integer.parseInt(modelo.getText().toString()), origen.getText().toString(), destino.getText().toString(), Integer.parseInt(pasaje.getText().toString())));
                    sendDialogDataToActivity(marca.getText().toString(), placa.getText().toString(), modelo.getText().toString(), origen.getText().toString(), destino.getText().toString(), pasaje.getText().toString(), true);

                    sendDialogDataToActivity("", "", "", "", "", "", false);
                    sendDialogDataToActivity("", "", "", "", "", "", false);
                    sendDialogDataToActivity("", "", "", "", "", "", false);
                }
                else
                {
                    colaRadioTaxis.adicionar(new RadioTaxi(marca.getText().toString(), placa.getText().toString(), Integer.parseInt(modelo.getText().toString()), origen.getText().toString(), destino.getText().toString(), Integer.parseInt(pasaje.getText().toString())));
                    sendDialogDataToActivity(marca.getText().toString(), placa.getText().toString(), modelo.getText().toString(), origen.getText().toString(), destino.getText().toString(), pasaje.getText().toString(), true);

                    sendDialogDataToActivity("", "", "", "", "", "", false);
                    sendDialogDataToActivity("", "", "", "", "", "", false);
                    sendDialogDataToActivity("", "", "", "", "", "", false);
                }
            }
        });
        // create and show the alert dialog

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void sendDialogDataToActivity(String data1, String data2, String data3, String data4, String data5, String data6, boolean sw1)
    {
        TableRow tr1 = new TableRow(this);

        tr1.setLayoutParams(new LinearLayout.LayoutParams( LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        TextView textview = new TextView(this), textview1 = new TextView(this), textview2 = new TextView(this), textview3 = new TextView(this), textview4 = new TextView(this), textview5 = new TextView(this);

        textview.setText(data1);
        textview1.setText(data2);
        textview2.setText(data3);
        textview3.setText(data4);
        textview4.setText(data5);
        textview5.setText(data6);

        textview.setWidth(130);
        textview1.setWidth(130);
        textview2.setWidth(130);
        textview3.setWidth(130);
        textview4.setWidth(130);
        textview5.setWidth(130);

        textview.setGravity(2);
        textview1.setGravity(2);
        textview2.setGravity(2);
        textview3.setGravity(2);
        textview4.setGravity(2);
        textview5.setGravity(2);

        tr1.addView(textview);
        tr1.addView(textview1);
        tr1.addView(textview2);
        tr1.addView(textview3);
        tr1.addView(textview4);
        tr1.addView(textview5);

        tr1.setBackgroundResource(R.color.idOfColour);

        tr1.setMinimumHeight(70);
        //tab1.addView(tr1); //aca condiciona esta linea
        if(sw1)
        {
            int nro = tab1.getChildCount();
            tab1.removeViewAt( nro - 1);
            tab1.removeViewAt(nro - 2);
            tab1.removeViewAt(nro - 3);
        }

        tab1.addView(tr1);

    }
    public void onButtonClick(View view) //a este procedimiento que debe estar en el boton back de android  y un extra para salir del layout
    {

        Intent intent = new Intent();
        intent.putExtra("tipoVehiculo", tipoVehiculo);

        intent.putExtra("posicion", pos);

        intent.putExtra("dpTaxi", pilaTaxis);
        intent.putExtra("dpRadioTaxi", colaRadioTaxis);

        intent.putExtra("listaPosicion", posicion);

        setResult(RESULT_OK, intent);
        finish();

    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        Intent intent = new Intent();
        intent.putExtra("tipoVehiculo", tipoVehiculo);

        intent.putExtra("posicion", pos);

        intent.putExtra("dpTaxi", pilaTaxis);
        intent.putExtra("dpRadioTaxi", colaRadioTaxis);

        intent.putExtra("listaPosicion", posicion);

        setResult(RESULT_OK, intent);
        finish();
    }
    public void eliminarTaxi(PilaT a, PilaT aux, String y)
    {
        if(!a.esVacia())
        {
            Taxi x = a.eliminar();
            if(!x.getPlaca().equals(y))
                aux.adicionar(x);
            eliminarTaxi(a, aux, y);
        }
        else
            a.vaciar(aux);
    }
    public void eliminarRadioTaxi(CSimpleRT a, CSimpleRT aux, String y)
    {
        if(!a.esVacia())
        {
            RadioTaxi x = a.eliminar();
            if(!x.getPlaca().equals(y))
                aux.adicionar(x);
            else
                System.out.println("encontrado");
            eliminarRadioTaxi(a, aux, y);
        }
        else
            a.vaciar(aux);
    }
    public void solucion3(View view)
    {
        EditText placa = (EditText)findViewById(R.id.licencePlateText);
        String y = placa.getText().toString();

        limpieza();
        if(tipoVehiculo == 1)
        {
            eliminarTaxi(pilaTaxis, new PilaT(), y);
            agregacionTaxis();
        }
        else {
            eliminarRadioTaxi(colaRadioTaxis, new CSimpleRT(), y);
            agregacionRadioTaxis();
        }
    }
}