package com.example.proyecto_lab_131;

import java.io.Serializable;

public class PilaM implements Serializable
{
    private int tope, max = 50;
    private Minibus v[] = new Minibus[max + 1];

    PilaM()
    {
        tope = 0;
    }

    public boolean esVacia()
    {
        return tope == 0;
    }
    public boolean esLlena()
    {
        return tope == max;
    }
    public int nroElementos()
    {
        return tope;
    }

    public void adicionar(Minibus x)
    {
        if(!esLlena())
        {
            tope++;
            v[tope] = x;
        }
    }
    public Minibus eliminar()
    {
        Minibus x = new Minibus("", "", -1);

        if(!esVacia())
        {
            x = v[tope];
            tope--;

        }

        return x;
    }

    public void vaciar(PilaM Z)
    {
        if(!Z.esVacia())
        {
            adicionar(Z.eliminar());
            vaciar(Z);
        }
    }
}
