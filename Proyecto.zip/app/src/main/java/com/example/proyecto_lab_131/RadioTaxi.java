package com.example.proyecto_lab_131;

import java.io.Serializable;

public class RadioTaxi extends Taxi implements Serializable
{
    public RadioTaxi(String marca, String placa, int modelo, String origen, String destino, int pasaje) {
        super(marca, placa, modelo, origen, destino, pasaje);
    }
}
