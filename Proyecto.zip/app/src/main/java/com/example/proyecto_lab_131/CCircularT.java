package com.example.proyecto_lab_131;

import java.io.Serializable;

public class CCircularT implements Serializable
{
    private int ini, fin, max = 50;
    private Trufi v[] = new Trufi[max + 1];

    CCircularT()
    {
        ini = fin = 0;
    }

    public boolean esVacia()
    {
        return (max - ini + fin) % max == 0;
    }
    public boolean esLlena()
    {
        return (max - ini + fin) % max == max - 1;
    }
    public int nroElementos()
    {
        return (max - ini + fin) % max;
    }

    public void adicionar(Trufi x)
    {
        if(!esLlena())
        {
            fin = (fin + 1) % max;
            v[fin] = x;
        }
    }
    public Trufi eliminar()
    {
        Trufi x = new Trufi("", "", -1);

        if(!esVacia())
        {
            ini = (ini + 1) % max;
            x = v[ini];
            if(ini == fin)
            {
                ini = fin = 0;
            }
        }

        return x;
    }

    public void vaciar(CCircularT Z)
    {
        while(!Z.esVacia())
            adicionar(Z.eliminar());
    }

    public void mostrar()
    {
        CCircularT aux = new CCircularT();
        while(!esVacia())
        {
            Trufi x = eliminar();
            System.out.println(x.getMarca());
            aux.adicionar(x);
        }
        vaciar(aux);
    }
}
