package com.example.proyecto_lab_131;

import java.io.Serializable;

public class Micro extends Vehiculo implements Serializable
{
    public Micro(String marca, String placa, int modelo) {
        super(marca, placa, modelo);
    }
}
