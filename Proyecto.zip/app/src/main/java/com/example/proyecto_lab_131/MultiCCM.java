package com.example.proyecto_lab_131;

import java.io.Serializable;

public class MultiCCM implements Serializable
{
    private CCircularM v[] = new CCircularM[20];
    private int n;

    MultiCCM()
    {
        for(int i = 0; i < 20; i++)
            v[i] = new CCircularM();
    }

    public int getN()
    {
        return n;
    }

    public void setN(int n)
    {
        this.n = n;
    }

    public boolean esVacia(int i)
    {
        return v[i].esVacia();
    }

    public boolean esLlena(int i)
    {
        return v[i].esLlena();
    }

    public void adicionar(int i, Micro x)
    {
        v[i].adicionar(x);
    }

    public Micro eliminar(int i)
    {
        return v[i].eliminar();
    }
    public void vaciar(int i, int j)
    {
        v[i].vaciar(v[j]);
    }
    public void vaciar(int i, CCircularM Z)
    {
        v[i].vaciar(Z);
    }
}
