package com.example.proyecto_lab_131;

import java.io.Serializable;

public class LSimpleEH implements Serializable
{
    private NodoEH p;

    LSimpleEH()
    {
        p = null;
    }

    public NodoEH getP() {
        return p;
    }

    public void setP(NodoEH p) {
        this.p = p;
    }

    public void adicionar(String x, int y)
    {
        NodoEH nue = new NodoEH();
        nue.setNombreEmpHot(x);
        nue.setTipoVehiculos(y);

        if(getP() == null)
            setP(nue);
        else
        {
            /*
            nue.setSig(getP());
            setP(nue);*/

            NodoEH z = getP();

            while(z.getSig() != null)
                z = z.getSig();

            z.setSig(nue);
        }
    }

    public void mostrar()
    {
        NodoEH r = getP();

        while(r != null)
        {
            System.out.println(r.getNombreEmpHot() + "---" + r.getTipoVehiculos());
            r = r.getSig();
        }
    }
}
