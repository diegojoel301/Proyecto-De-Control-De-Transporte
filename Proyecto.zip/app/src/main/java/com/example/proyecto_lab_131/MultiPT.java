package com.example.proyecto_lab_131;

import java.io.Serializable;

public class MultiPT implements Serializable
{
    private PilaT v[] = new PilaT[20];
    private int n;

    MultiPT()
    {
        for(int i = 0; i < 20; i++)
            v[i] = new PilaT();
    }

    public int getN()
    {
        return n;
    }

    public void setN(int n)
    {
        this.n = n;
    }

    public boolean esVacia(int i)
    {
        return v[i].esVacia();
    }

    public boolean esLlena(int i)
    {
        return v[i].esLlena();
    }

    public void adicionar(int i, Taxi x)
    {
        v[i].adicionar(x);
    }

    public Taxi eliminar(int i)
    {
        return v[i].eliminar();
    }
    public void vaciar(int i, int j)
    {
        v[i].vaciar(v[j]);
    }
    public void vaciar(int i, PilaT Z)
    {
        v[i].vaciar(Z);
    }
}
