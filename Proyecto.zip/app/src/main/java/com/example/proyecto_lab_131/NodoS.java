package com.example.proyecto_lab_131;

import java.io.Serializable;

public class NodoS implements Serializable
{
    private String sindicato;
    private NodoS ant, sig;
    private LDCircularOD a;
    private int tipoVehiculos; //1: Trufis, 2: Minibuses, 3: Micros

    NodoS()
    {
        ant = sig = null;
    }

    public String getSindicato() {
        return sindicato;
    }

    public void setSindicato(String sindicato) {
        this.sindicato = sindicato;
    }

    public NodoS getAnt() {
        return ant;
    }

    public void setAnt(NodoS ant) {
        this.ant = ant;
    }

    public NodoS getSig() {
        return sig;
    }

    public void setSig(NodoS sig) {
        this.sig = sig;
    }

    public LDCircularOD getA() {
        return a;
    }

    public void setA(LDCircularOD a) {
        this.a = a;
    }

    public int getTipoVehiculos() { return tipoVehiculos; }

    public void setTipoVehiculos(int tipoVehiculos) { this.tipoVehiculos = tipoVehiculos; }
}
