package com.example.proyecto_lab_131;

import java.io.Serializable;

public class Minibus extends Vehiculo implements Serializable
{
    public Minibus(String marca, String placa, int modelo) {
        super(marca, placa, modelo);
    }
}
