package com.example.proyecto_lab_131;

import java.io.Serializable;

public class NodoEH implements Serializable
{
    private String nombreEmpHot;
    private NodoEH sig;
    private int tipoVehiculos; //1: taxis, 2: radiotaxis

    NodoEH()
    {
        sig = null;
    }

    public String getNombreEmpHot() {
        return nombreEmpHot;
    }

    public void setNombreEmpHot(String nombreEmpHot) {
        this.nombreEmpHot = nombreEmpHot;
    }

    public NodoEH getSig() {
        return sig;
    }

    public void setSig(NodoEH sig) {
        this.sig = sig;
    }

    public int getTipoVehiculos() {
        return tipoVehiculos;
    }

    public void setTipoVehiculos(int tipoVehiculos) {
        this.tipoVehiculos = tipoVehiculos;
    }
}
