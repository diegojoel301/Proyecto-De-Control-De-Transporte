package com.example.proyecto_lab_131;

import java.io.Serializable;

public class PilaT implements Serializable
{
    private int tope, max = 50;
    private Taxi v[] = new Taxi[max + 1];

    PilaT()
    {
        tope = 0;
    }

    public boolean esVacia()
    {
        return tope == 0;
    }
    public boolean esLlena()
    {
        return tope == max;
    }
    public int nroElementos()
    {
        return tope;
    }

    public void adicionar(Taxi x)
    {
        if(!esLlena())
        {
            tope++;
            v[tope] = x;
        }
    }
    public Taxi eliminar()
    {
        Taxi x = new Taxi("", "", -1, "", "", -1);

        if(!esVacia())
        {
            x = v[tope];
            tope--;

        }

        return x;
    }

    public void vaciar(PilaT Z)
    {
        if(!Z.esVacia())
        {
            adicionar(Z.eliminar());
            vaciar(Z);
        }
    }
    public void mostrar()
    {
        PilaT aux = new PilaT();
        while(!esVacia())
        {
            Taxi x = eliminar();
            System.out.println(x.getMarca() + " " + x.getPlaca() + " " + x.getModelo());
            aux.adicionar(x);
        }
        vaciar(aux);
    }
}
