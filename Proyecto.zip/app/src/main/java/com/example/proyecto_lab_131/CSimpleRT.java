package com.example.proyecto_lab_131;

import java.io.Serializable;

public class CSimpleRT implements Serializable
{
    private int ini, fin, max = 50;
    private RadioTaxi v[] = new RadioTaxi[max + 1];

    CSimpleRT()
    {
        ini = fin = 0;
    }

    public boolean esVacia()
    {
        return ini == fin;
    }
    public boolean esLlena()
    {
        return fin == max;
    }
    public int nroElementos()
    {
        return fin - ini;
    }

    public void adicionar(RadioTaxi x)
    {
        if(!esLlena())
        {
            fin = fin + 1;
            v[fin] = x;
        }
    }
    public RadioTaxi eliminar()
    {
        RadioTaxi x = new RadioTaxi("", "", -1, "", "", -1);

        if(!esVacia())
        {
            ini = ini + 1;
            x = v[ini];
            if(ini == fin)
                ini = fin = 0;
        }

        return x;
    }

    public void vaciar(CSimpleRT Z)
    {
        while(!Z.esVacia())
            adicionar(Z.eliminar());
    }
    public void mostrar()
    {
        CSimpleRT aux = new CSimpleRT();
        while(!esVacia())
        {
            RadioTaxi x = eliminar();
            System.out.println(x.getMarca() + " " + x.getDestino() + " " + x.getOrigen() + " " + x.getPlaca());
            aux.adicionar(x);
        }
        vaciar(aux);
    }
}
