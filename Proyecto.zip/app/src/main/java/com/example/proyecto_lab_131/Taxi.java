package com.example.proyecto_lab_131;

import java.io.Serializable;

public class Taxi extends Vehiculo implements Serializable
{
    private String origen, destino;
    private int pasaje;

    public Taxi(String marca, String placa, int modelo, String origen, String destino, int pasaje) {
        super(marca, placa, modelo);
        this.origen = origen;
        this.destino = destino;
        this.pasaje = pasaje;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public int getPasaje() {
        return pasaje;
    }

    public void setPasaje(int pasaje) {
        this.pasaje = pasaje;
    }
}
