package com.example.proyecto_lab_131;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class Sindicato_Activity extends AppCompatActivity
{
    private TableLayout tab1, tab2;

    private int tipoVehiculo, pos, posicion;

    //objetos pertenecientes al sindicato con los cuales trabajaremos
    //private NodoOD nodeOriginDestiny;
    private LDCircularOD A = new LDCircularOD();
    private CCircularT trufiSend = new CCircularT(); // tipo: 1
    private PilaM miniSend = new PilaM(); // tipo: 2
    private CCircularM microSend = new CCircularM(); // tipo: 3

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sindicatos);
        //aca los botones editText e demas layouts a declarar
        tab1 = (TableLayout)findViewById(R.id.tableVehiculo);
        tab2 = (TableLayout)findViewById(R.id.tableVehiculos);

        pos = getIntent().getIntExtra("posicion", - 1);
        tipoVehiculo = getIntent().getIntExtra("tipoVehiculo", -1);
        A = (LDCircularOD) getIntent().getSerializableExtra("ListaOrigenDestinos");
        posicion = getIntent().getIntExtra("posicionLista", -1);
        switch (tipoVehiculo)
        {
            case 1:
                trufiSend = (CCircularT)getIntent().getSerializableExtra("multi");
                //proceso de llenado

                CCircularT aux = new CCircularT();

                while(!trufiSend.esVacia())
                {
                    Trufi x = trufiSend.eliminar();
                    sendDialogDataToActivity(x.getMarca(), x.getPlaca(), x.getModelo()+ "", false, true);
                    sendDialogDataToActivity("", "", "", false, false);
                    sendDialogDataToActivity("", "", "", false, false);
                    sendDialogDataToActivity("", "", "", false, false);
                    aux.adicionar(x);
                }
                trufiSend.vaciar(aux);
                break;
            case 2:
                miniSend = (PilaM)getIntent().getSerializableExtra("multi1");

                PilaM aux1 = new PilaM();

                while(!miniSend.esVacia())
                {
                    Minibus x = miniSend.eliminar();
                    sendDialogDataToActivity(x.getMarca(), x.getPlaca(), x.getModelo()+ "", false, true);
                    sendDialogDataToActivity("", "", "", false, false);
                    sendDialogDataToActivity("", "", "", false, false);
                    sendDialogDataToActivity("", "", "", false, false);
                    aux1.adicionar(x);
                }
                miniSend.vaciar(aux1);

                break;
            case 3:
                microSend = (CCircularM)getIntent().getSerializableExtra("multi2");

                CCircularM aux2 = new CCircularM();

                while(!microSend.esVacia())
                {
                    Micro x = microSend.eliminar();
                    sendDialogDataToActivity(x.getMarca(), x.getPlaca(), x.getModelo()+ "", false, true);
                    sendDialogDataToActivity("", "", "", false, false);
                    sendDialogDataToActivity("", "", "", false, false);
                    sendDialogDataToActivity("", "", "", false, false);
                    microSend.adicionar(x);
                }
                microSend.vaciar(aux2);
                break;
        }
        if(A.getP() != null)
        {
            NodoOD w = A.getP();

            while (w.getSig() != A.getP()) {
                sendDialogDataToActivity(w.getOrigen(), w.getDestino(), w.getPasaje() + "", true, true);
                sendDialogDataToActivity("", "", "", true, false);
                sendDialogDataToActivity("", "", "", true, false);
                sendDialogDataToActivity("", "", "", true, false);
                w = w.getSig();
            }

            sendDialogDataToActivity(w.getOrigen(), w.getDestino(), w.getPasaje() + "", true, true);
            sendDialogDataToActivity("", "", "", true, false);
            sendDialogDataToActivity("", "", "", true, false);
            sendDialogDataToActivity("", "", "", true, false);
        }
    }
    @Override
    protected void onPause()
    { //debemos hacer que se pause la aplicacion y sea null nuestro objeto posterior a este proceso se prodecede a la serializacion de deicho objeto
        super.onPause();
        //obj = null; // temporal
        //nodeOriginDestiny = null;
        A = null;
        trufiSend = null;
        miniSend = null;
        microSend = null;
    }
    public void adicionarOrigenDestino(View view)
    {
        // create an alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Agragacion de Origen-Destinos");

        // set the custom layout
        final View customLayout = getLayoutInflater().inflate(R.layout.origen_destino_sindicato, null);
        builder.setView(customLayout);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // send data from the AlertDialog to the Activity

                EditText origen = customLayout.findViewById(R.id.editText1);
                EditText destino = customLayout.findViewById(R.id.editText2);
                EditText pasaje = customLayout.findViewById(R.id.editTextNumber);
                A.adicionar(origen.getText().toString(), destino.getText().toString(), Integer.parseInt(pasaje.getText().toString()));

                sendDialogDataToActivity(origen.getText().toString(), destino.getText().toString(), pasaje.getText().toString(), true, true);
                sendDialogDataToActivity("", "", "", true, false);
                sendDialogDataToActivity("", "", "", true, false);
                sendDialogDataToActivity("", "", "", true, false);
            }
        });
        // create and show the alert dialog

        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void adicionarVehiculo(View view)
    {
        // create an alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Agragacion de Vehiculo");

        // set the custom layout
        final View customLayout = getLayoutInflater().inflate(R.layout.agregacion_vehiculo_sindicato, null);
        builder.setView(customLayout);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // send data from the AlertDialog to the Activity

                EditText marca = customLayout.findViewById(R.id.editText1);
                EditText placa = customLayout.findViewById(R.id.editText2);
                EditText modelo = customLayout.findViewById(R.id.editTextNumber);

                switch (tipoVehiculo)
                {
                    case 1:
                        trufiSend.adicionar(new Trufi(marca.getText().toString(), placa.getText().toString(), Integer.parseInt(modelo.getText().toString())));
                        break;
                    case 2:
                        miniSend.adicionar(new Minibus(marca.getText().toString(), placa.getText().toString(), Integer.parseInt(modelo.getText().toString())));
                        break;
                    case 3:
                        microSend.adicionar(new Micro(marca.getText().toString(), placa.getText().toString(), Integer.parseInt(modelo.getText().toString())));
                        break;
                }

                sendDialogDataToActivity(marca.getText().toString(), placa.getText().toString(), modelo.getText().toString(), false, true);
                sendDialogDataToActivity("", "", "", false, false);
                sendDialogDataToActivity("", "", "", false, false);
                sendDialogDataToActivity("", "", "", false, false);
            }
        });
        // create and show the alert dialog

        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void sendDialogDataToActivity(String data1, String data2, String data3, boolean sw, boolean sw1)
    {
        TableRow tr1 = new TableRow(this);

        tr1.setLayoutParams(new LinearLayout.LayoutParams( LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        TextView textview = new TextView(this), textview1 = new TextView(this), textview2 = new TextView(this), textview3 = new TextView(this);

        textview.setText(data1);
        textview1.setText(data2);
        textview2.setText(data3);

        textview.setWidth(250);
        textview1.setWidth(250);
        textview2.setWidth(250);

        textview.setGravity(2);
        textview1.setGravity(2);
        textview2.setGravity(2);

        tr1.addView(textview);
        tr1.addView(textview1);
        tr1.addView(textview2);

        tr1.setBackgroundResource(R.color.idOfColour);

        tr1.setMinimumHeight(70);
        //tab1.addView(tr1); //aca condiciona esta linea
        if(sw)
        {

            if(sw1)
            {
                int nro = tab1.getChildCount();
                tab1.removeViewAt( nro - 1);
                tab1.removeViewAt(nro - 2);
                tab1.removeViewAt(nro - 3);
            }

            tab1.addView(tr1);
        }
        else
        {

            if(sw1)
            {
                int nro = tab2.getChildCount();
                tab2.removeViewAt( nro - 1);
                tab2.removeViewAt(nro - 2);
                tab2.removeViewAt(nro - 3);
            }

            tab2.addView(tr1);
        }
    }
    public void onButtonClick(View view) //a este procedimiento que debe estar en el boton back de android  y un extra para salir del layout
    {
        Intent intent = new Intent();
        intent.putExtra("tipoVehiculo", tipoVehiculo);
        intent.putExtra("posicion", pos);

        intent.putExtra("dpTrufi", trufiSend);
        intent.putExtra("dpMini", miniSend);
        intent.putExtra("dpMicro", microSend);

        intent.putExtra("dpOD", A);


        intent.putExtra("listaPosicion", posicion);

        setResult(RESULT_OK, intent);
        finish();

    }
    public String mostrarVehiculosModeloYtrufis(CCircularT a, CCircularT aux, int y)
    {
        if(!a.esVacia())
        {
            Trufi x = a.eliminar();
            aux.adicionar(x);
            if(x.getModelo() == y)
                return x.getMarca() + " " + x.getPlaca() + " " + x.getModelo() + "\n" + mostrarVehiculosModeloYtrufis(a, aux, y);
            return mostrarVehiculosModeloYtrufis(a, aux, y);
        }

        else{
            a.vaciar(aux);
            return "";
        }
    }
    public String mostrarVehiculosModeloYminibuses(PilaM a, PilaM aux, int y)
    {
        if(!a.esVacia())
        {
            Minibus x = a.eliminar();
            aux.adicionar(x);
            if(x.getModelo() == y)
                return x.getMarca() + " " + x.getPlaca() + " " + x.getModelo() + "\n" + mostrarVehiculosModeloYminibuses(a, aux, y);
            return mostrarVehiculosModeloYminibuses(a, aux, y);
        }
        else
        {
            a.vaciar(aux);
            return "";
        }
    }
    public String mostrarVehiculosModeloYmicros(CCircularM a, CCircularM aux, int y)
    {
        if(!a.esVacia())
        {
            Micro x = a.eliminar();
            aux.adicionar(x);
            if(x.getModelo() == y)
                return x.getMarca() + " " + x.getPlaca() + " " + x.getModelo() + "\n" + mostrarVehiculosModeloYmicros(a, aux, y);
            return mostrarVehiculosModeloYmicros(a, aux, y);
        }
        else
        {
            a.vaciar(aux);
            return "";
        }
    }
    public void solucion2(View view)
    {
        try
        {
            EditText model = (EditText)findViewById(R.id.numberModel);

            int y = Integer.parseInt(model.getText().toString());

            String out = "";
            if(tipoVehiculo == 1)
                out = mostrarVehiculosModeloYtrufis(trufiSend, new CCircularT(), y);
            if(tipoVehiculo == 2)
                out = mostrarVehiculosModeloYminibuses(miniSend, new PilaM(), y);
            if(tipoVehiculo == 3)
                out = mostrarVehiculosModeloYmicros(microSend, new CCircularM(), y);

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Vehiculos de modelo: " + y);
            builder.setMessage("Marca\tPlaca\t Modelo" + "\n" + out);
            AlertDialog dialog = builder.create();
            dialog.show();
        }
        catch (NumberFormatException e)
        {
            System.out.println(e.getCause());
        }

    }
}