package com.example.proyecto_lab_131;

import java.io.Serializable;

public class LDCircularOD implements Serializable
{
    private NodoOD p;

    LDCircularOD()
    {
        p = null;
    }

    public NodoOD getP() {
        return p;
    }

    public void setP(NodoOD p) {
        this.p = p;
    }

    public void adicionar(String x, String y, int w)
    {
        NodoOD nue = new NodoOD();
        nue.setOrigen(x);
        nue.setDestino(y);
        nue.setPasaje(w);

        if(getP() == null)
        {
            nue.setSig(nue);
            nue.setAnt(nue);
            setP(nue);
        }
        else
        {
            NodoOD z = getP();
            while(z.getSig() != getP())
                z = z.getSig();
            getP().setAnt(nue);
            nue.setSig(getP());
            setP(nue);
            z.setSig(getP());
        }
    }

    public void adicionar(NodoOD nue)
    {
        if(getP() == null)
        {
            nue.setSig(nue);
            nue.setAnt(nue);
            setP(nue);
        }
        else
        {
            NodoOD z = getP();
            while(z.getSig() != getP())
                z = z.getSig();
            getP().setAnt(nue);
            nue.setSig(getP());
            setP(nue);
            z.setSig(getP());
        }
    }
    public void mostrar()
    {
        NodoOD r = getP();

        while(r.getSig() != getP())
        {
            System.out.println("\n" + r.getOrigen() + " " + r.getDestino() + " " + r.getPasaje());
            r = r.getSig();
        }
        System.out.println("\n" + r.getOrigen() + " " + r.getDestino() + " " + r.getPasaje());
    }
}
