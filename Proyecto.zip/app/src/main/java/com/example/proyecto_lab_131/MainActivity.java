package com.example.proyecto_lab_131;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    private static final int SECOND_ACTIVITY_REQUEST_CODE = 0;
    private TextView tv1;
    private EditText ed1;
    private TableLayout tab1, tab2;
    //estruturas de datos principales
    private LDobleS listaSindicatos;
    private LSimpleEH listaEmpHot;
    //estruturas de datos secundarias
    private MultiCCT multiTrufis;
    private MultiPM multiMiniBuses;
    private MultiCCM multiMicros;
    private MultiPT multiTaxis;
    private MultiCRT multiRadioTaxis;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "Inicio", Toast.LENGTH_SHORT).show();
        // La actividad está a punto de hacerse visible.
        /*
        tv1 = (TextView) findViewById((R.id.textView5));
        ed1 = (EditText)findViewById(R.id.textInputEditText);
        */
        tab1 = (TableLayout)findViewById(R.id.tableSindicatos);
        tab2 = (TableLayout)findViewById(R.id.tableEmpHot);

        listaSindicatos  = new LDobleS();
        listaEmpHot = new LSimpleEH();

        multiTrufis = new MultiCCT();
        multiMiniBuses = new MultiPM();
        multiMicros = new MultiCCM();

        multiTaxis = new MultiPT();
        multiRadioTaxis = new MultiCRT();

        llenarDatos();
    }

    public void agregaSindicato(View view)
    {
        showAlertDialogButtonClicked("sindicato","\n1)Trufis\n2)Minibuses\n3)Micros", true);
    }
    public void agregaEmpHot(View view)
    {
        showAlertDialogButtonClicked("Hoteles u Empresas","\n1)Taxi\n2)RadioTaxi", false);
    }

    public void showAlertDialogButtonClicked(String sinEmpHot, String type, boolean sw) //si sw es true pues este debe agregar a la tabla de sindicatos caso contrario a las de empresa u hotel
    {

        // create an alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Agragacion " + sinEmpHot);

        // set the custom layout
        final View customLayout = getLayoutInflater().inflate(R.layout.custom_layout, null);
        builder.setView(customLayout);

        TextView text1 = customLayout.findViewById(R.id.textView12);
        //text1.setText("Introduce nombre del" + "sindicato");
        text1.setText("Introduce nombre del" + sinEmpHot);
        TextView text2 = customLayout.findViewById(R.id.textView9);
        //text2.setText("Introduce tipo de Vehiculo: " + "\n1)Trufis\n2)Minibuses\n3)Micros");
        text2.setText("Introduce tipo de Vehiculo: " + type);
        // add a button
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                // send data from the AlertDialog to the Activity
                //builder.setMessage("Introduce nombre del sindicato");

                EditText editText = customLayout.findViewById(R.id.editText2);
                EditText editText2 = customLayout.findViewById(R.id.editTextNumber);
                String type = "";
                if(sw)
                {
                    listaSindicatos.adicionar(editText.getText().toString(), Integer.parseInt(editText2.getText().toString()), new LDCircularOD());
                    switch(Integer.parseInt(editText2.getText().toString()))
                    {
                        case 1:
                            type = "Trufis";
                            break;
                        case 2:
                            type = "Minibuses";
                            break;
                        case 3:
                            type = "Micros";
                            break;
                    }
                }
                else
                    {
                    listaEmpHot.adicionar(editText.getText().toString(), Integer.parseInt(editText2.getText().toString()));
                        switch(Integer.parseInt(editText2.getText().toString()))
                        {
                            case 1:
                                type = "Taxis";
                                break;
                            case 2:
                                type = "RadioTaxis";
                                break;
                        }
                }

                //sendDialogDataToActivity(editText.getText().toString(), editText2.getText().toString(), sw); //enviar los datos a la lista correspondiente
                sendDialogDataToActivity(editText.getText().toString(), type, sw, true);
                sendDialogDataToActivity("","", sw, false);
                sendDialogDataToActivity("","", sw, false);
                sendDialogDataToActivity("","", sw, false);
            }
        });
        // create and show the alert dialog

        AlertDialog dialog = builder.create();
        dialog.show();
    }
    // do something with the data coming from the AlertDialog
    private void sendDialogDataToActivity(String data1, String data2, boolean sw, boolean sw1)
    {
        //Toast.makeText(this, data, Toast.LENGTH_SHORT).show();
        //String data = "", data2 = "0", data3 = "0", data4 = "";

        TableRow tr1 = new TableRow(this);

        tr1.setLayoutParams(new LinearLayout.LayoutParams( LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        TextView textview = new TextView(this), textview3 = new TextView(this);

        textview.setText(data1);
        textview3.setText(data2);

        textview.setWidth(400);
        textview3.setWidth(400);

        textview.setGravity(2);
        textview3.setGravity(2);

        tr1.addView(textview);
        tr1.addView(textview3);

        tr1.setBackgroundResource(R.color.idOfColour);

        tr1.setMinimumHeight(70);
        //tab1.addView(tr1); //aca condiciona esta linea
        if(sw)
        {

            if(sw1)
            {
                int nro = tab1.getChildCount();
                tab1.removeViewAt( nro - 1);
                tab1.removeViewAt(nro - 2);
                tab1.removeViewAt(nro - 3);
            }

            tab1.addView(tr1);
        }
        else
            {

                if(sw1)
                {
                    int nro = tab2.getChildCount();
                    tab2.removeViewAt( nro - 1);
                    tab2.removeViewAt(nro - 2);
                    tab2.removeViewAt(nro - 3);
                }

                tab2.addView(tr1);
        }
    }

    /** Called when the user clicks the Send button */

    public void sendMessage(int tipo, int pos, LDCircularOD lod, int posicion) {

        final int REQUEST_CODE=101;
        Intent intent = new Intent(this, Sindicato_Activity.class);
        intent.putExtra("tipoVehiculo",tipo); //enviamos el tipo de vehiculo al cual le corresponde a dicho sindicato
        intent.putExtra("posicion",pos);
        Bundle b = new Bundle();

        //dependiendo del tipo de estructura y posicion se enviara la respectiva estructura
        CCircularT trufiSend = new CCircularT(); // tipo: 1
        PilaM miniSend = new PilaM(); // tipo: 2
        CCircularM microSend = new CCircularM(); // tipo: 3

        switch (tipo) //teniendo en cuenta el tipo pues enviaremos la respectiva multiestructura del respectivo vehiculo al que corresponde el sindicato desde el cual se ejecuta esta funcion
        {
            case 1:
                while(!multiTrufis.esVacia(pos))
                    trufiSend.adicionar(multiTrufis.eliminar(pos));
                b.putSerializable("multi", trufiSend);
                break;
            case 2:
                while(!multiMiniBuses.esVacia(pos))
                    miniSend.adicionar(multiMiniBuses.eliminar(pos));
                b.putSerializable("multi1", miniSend);
                break;
            case 3:
                while(!multiMicros.esVacia(pos))
                    microSend.adicionar(multiMicros.eliminar(pos));
                b.putSerializable("multi2", microSend);
                break;
        }
        intent.putExtras(b);

        intent.putExtra("ListaOrigenDestinos", lod);

        intent.putExtra("posicionLista", posicion);

        //startActivityForResult(intent, SECOND_ACTIVITY_REQUEST_CODE);

        startActivityForResult(intent, REQUEST_CODE);
    }

    public void sendMessage1(int tipo, int pos, int posicion) {

        final int REQUEST_CODE=102;
        Intent intent = new Intent(this, EmpHot_Activity.class);
        intent.putExtra("tipoVehiculo",tipo); //enviamos el tipo de vehiculo al cual le corresponde a dicho sindicato
        intent.putExtra("posicion",pos);
        Bundle b = new Bundle();

        //dependiendo del tipo de estructura y posicion se enviara la respectiva estructura
        PilaT taxiSend = new PilaT();
        CSimpleRT radioTaxiSend = new CSimpleRT();

        switch (tipo) //teniendo en cuenta el tipo pues enviaremos la respectiva multiestructura del respectivo vehiculo al que corresponde el sindicato desde el cual se ejecuta esta funcion
        {
            case 1:

                while(!multiTaxis.esVacia(pos))
                    taxiSend.adicionar(multiTaxis.eliminar(pos));
                b.putSerializable("multi", taxiSend);
                break;
            case 2:
                while(!multiRadioTaxis.esVacia(pos))
                    radioTaxiSend.adicionar(multiRadioTaxis.eliminar(pos));
                b.putSerializable("multi1", radioTaxiSend);
                break;
        }

        intent.putExtras(b);

        intent.putExtra("posicionLista", posicion);

        startActivityForResult(intent, REQUEST_CODE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

            if(requestCode == 101) {
                try
                {
                    int tipoVehiculo = data.getIntExtra("tipoVehiculo", -1), pos = data.getIntExtra("posicion", -1);
                    int posicion = data.getIntExtra("listaPosicion", -1);
                    switch (tipoVehiculo) {
                        case 1:
                            CCircularT trufiReceived = (CCircularT) data.getSerializableExtra("dpTrufi");
                            multiTrufis.vaciar(pos, trufiReceived);
                            break;
                        case 2:
                            PilaM miniReceived = (PilaM) data.getSerializableExtra("dpMini");
                            multiMiniBuses.vaciar(pos, miniReceived);
                            break;
                        case 3:
                            CCircularM microReceived = (CCircularM) data.getSerializableExtra("dpMicro");
                            multiMicros.vaciar(pos, microReceived);
                            break;
                    }

                    LDCircularOD lod = (LDCircularOD) data.getSerializableExtra("dpOD");

                    int k = 0;

                    NodoS w = listaSindicatos.getP();

                    while (w != null) {
                        if (k == posicion)
                            w.getA().setP(lod.getP());
                        k++;
                        w = w.getSig();
                    }
                }
                catch (NullPointerException e)
                {
                    System.out.println(e.getCause());
                }

            }
            if(requestCode == 102)
            {
                try
                {
                    int tipoVehiculo = data.getIntExtra("tipoVehiculo", -1), pos = data.getIntExtra("posicion", -1);

                    switch (tipoVehiculo) {
                        case 1:
                            PilaT taxiReceived = (PilaT) data.getSerializableExtra("dpTaxi");
                            multiTaxis.vaciar(pos, taxiReceived);
                            break;
                        case 2:
                            CSimpleRT radioTaxiReceived = (CSimpleRT) data.getSerializableExtra("dpRadioTaxi");
                            multiRadioTaxis.vaciar(pos, radioTaxiReceived);
                            break;
                    }
                }
                catch (NullPointerException e)
                {
                    System.out.println(e.getCause());
                }
            }

    }

    public void ingresarSindicato(View view)
    {
        NodoS r = listaSindicatos.getP();

        EditText edt_Sindicato = (EditText)findViewById(R.id.textInputEditText_1);
        String nombreSindicato = edt_Sindicato.getText().toString();

        boolean sw = false; //sw: representa la existencia del sindicato de nombreSindicato ademas nos sirve para cortar el recorrido de la lista en caso de haber encontrado dicho sindicato
        int pos = -1, tipo = -1, posicion = -1; //esta es la posicion de la multiestructura que le corresponde a dicho sindicato
        LDCircularOD lds = new LDCircularOD();
        while(r != null && !sw)
        {
            if(!sw)
                posicion++;
            if(r.getSindicato().equals(nombreSindicato))
            {
                tipo = r.getTipoVehiculos();

                NodoS w = r;//tomamos w como el mismo r para que recorra para atras y vaya incrementando pos de ese modo obtendremos la posicion correspondiente a la multiestructura
                sw = true; //el sw cambia es decir en el siguiente r = r.getSig() seria ya el final de este recorrido
                //NodoOD nodeOriginDestiny = r.getA().getP();
                lds = r.getA();
                while(w != null) //recorremos para atras la lista a partir del nodo r que ahora sera w el que recorrera
                {
                    if(w.getTipoVehiculos() == tipo)
                        pos++;
                    w = w.getAnt();
                }
            }
            r = r.getSig();
        }

        if(sw)
            sendMessage(tipo, pos, lds, posicion);
        else
            Toast.makeText(this, "No existe", Toast.LENGTH_SHORT).show();


    }
    public void ingresarEmpHot(View view)
    {
        NodoEH r = listaEmpHot.getP();

        EditText edt_EmpHot = (EditText)findViewById(R.id.textInputEditText_2);
        String nombreEmpHot = edt_EmpHot.getText().toString();

        boolean sw = false; //sw: representa la existencia del sindicato de nombreSindicato ademas nos sirve para cortar el recorrido de la lista en caso de haber encontrado dicho sindicato
        int pos = -1, tipo = -1, posicion = -1; //esta es la posicion de la multiestructura que le corresponde a dicho sindicato
        //NodoOD nodeOriginDestiny;

        while(r != null && !sw)
        {
            if(!sw)
                posicion++;
            if(r.getNombreEmpHot().equals(nombreEmpHot))
            {
                tipo = r.getTipoVehiculos();

                NodoEH w = r;//tomamos w como el mismo r para que recorra para atras y vaya incrementando pos de ese modo obtendremos la posicion correspondiente a la multiestructura
                sw = true; //el sw cambia es decir en el siguiente r = r.getSig() seria ya el final de este recorrido
            }
            r = r.getSig();
        }

        r = listaEmpHot.getP();

        int k = 0;

        while(r != null)
        {
            if(k <= posicion)
            {
                if (tipo == r.getTipoVehiculos())
                    pos++;
            }
            k++;
            r = r.getSig();
        }

        System.out.println(pos + " " + tipo);
        if(sw)
            sendMessage1(tipo, pos, posicion);
        else
            Toast.makeText(this, "No existe", Toast.LENGTH_SHORT).show();


    }

    public void limpieza(boolean sw)
    {
        int nro = tab1.getChildCount();

        for(int i = 2; i < nro; i++)
            tab1.removeViewAt(1);
        sendDialogDataToActivity("","", sw, false);
        sendDialogDataToActivity("","", sw, false);
    }
    public void llenarListaSindicato(NodoS r)
    {
        if(r != null)
        {
            if(r.getTipoVehiculos() == 1)
                sendDialogDataToActivity(r.getSindicato(),  "Trufi", true, true);
            if(r.getTipoVehiculos() == 2)
                sendDialogDataToActivity(r.getSindicato(),  "Minibuses", true, true);
            if(r.getTipoVehiculos() == 3)
                sendDialogDataToActivity(r.getSindicato(),  "Micros", true, true);
            sendDialogDataToActivity("","", true, false);
            sendDialogDataToActivity("","", true, false);
            sendDialogDataToActivity("","", true, false);
            llenarListaSindicato(r.getSig());
        }
    }
    public void llenarListaEmpHot(NodoEH r)
    {
        if(r != null)
        {
            if(r.getTipoVehiculos() == 1)
                sendDialogDataToActivity(r.getNombreEmpHot(),  "Taxis", false, true);
            if(r.getTipoVehiculos() == 2)
                sendDialogDataToActivity(r.getNombreEmpHot(),  "RadioTaxis", false, true);
            sendDialogDataToActivity("","", false, false);
            sendDialogDataToActivity("","", false, false);
            sendDialogDataToActivity("","", false, false);
            llenarListaEmpHot(r.getSig());
        }
    }
    //APARTADO DE EJERCICIOS
    public int sumarTotalTaxis(MultiPT a, int i)
    {
        if(!a.esVacia(i))
        {
            return sumarTotalTaxis(a, i + 1) + sumarTaxisIndividual(a, new PilaT(), i);
        }
        else
            return 0;
    }
    public int sumarTaxisIndividual(MultiPT a, PilaT aux, int i)
    {
        if(!a.esVacia(i))
        {
            Taxi x = a.eliminar(i);
            aux.adicionar(x);
            return sumarTaxisIndividual(a, aux, i) + x.getPasaje();
        }
        else
        {
            a.vaciar(i, aux);
            return 0;
        }
    }
    public int sumarTotalRadioTaxis(MultiCRT a, int i)
    {
        if(!a.esVacia(i))
        {
            return sumarTotalRadioTaxis(a, i + 1) + sumarRadioTaxisIndividual(a, new CSimpleRT(), i);
        }
        else
            return 0;
    }
    public int sumarRadioTaxisIndividual(MultiCRT a, CSimpleRT aux, int i)
    {
        if(!a.esVacia(i))
        {
            RadioTaxi x = a.eliminar(i);
            aux.adicionar(x);
            return sumarRadioTaxisIndividual(a, aux, i) + x.getPasaje();
        }
        else
        {
            a.vaciar(i, aux);
            return 0;
        }
    }

    public int sumaPasajesSindicatos(NodoS r)
    {
        if(r != null) {
            if(r.getA().getP() != null)
                return sumaPasajesRutas(r.getA().getP(), r.getA()) + sumaPasajesSindicatos(r.getSig());
            else
                return sumaPasajesSindicatos(r.getSig());
        }
        else
            return 0;
    }

    public int sumaPasajesRutas(NodoOD r, LDCircularOD a)
    {
        if(r.getSig() != a.getP())
            return r.getPasaje() + sumaPasajesRutas(r.getSig(), a);
        else {
            return r.getPasaje();
        }
    }

    public void solucion1(View view)
    {
        listaSindicatos.mostrar();
        int sumaTotalSindicatos = sumaPasajesSindicatos(listaSindicatos.getP());
        int sumaTotalEmpHot = sumarTotalRadioTaxis(multiRadioTaxis, 0) + sumarTotalTaxis(multiTaxis, 0);
        String out = "";
        if(sumaTotalSindicatos > sumaTotalEmpHot)
            out = "Los pasajes en total de los sindicatos supera ala de las empresas u hoteles en: " + sumaTotalSindicatos + " a comparacion de las empresas u hoteles con " + sumaTotalEmpHot;
        else
        {
            if(sumaTotalSindicatos < sumaTotalEmpHot)
                out = "Los pasajes en total de empresas u hoteles supera a la de los sindicatos en: " + sumaTotalEmpHot + " a comparacion de los sindicatos con " + sumaTotalSindicatos;
            else
                out = "Tanto los pasajes de los sindicatos son iguales a la de las empresas u hoteles con un total de pasajes de " + sumaTotalSindicatos;
        }
        //el mostrado en pantalla
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Cantidad pasajes sindicatos vs emperesas u hoteles");
        builder.setMessage(out);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void ordenarListaPorCategoria()
    {
        int nro = nroNodos(listaSindicatos.getP());

        for(int i = 0; i < nro; i++)
        {
            NodoS r = listaSindicatos.getP();
            if(r.getTipoVehiculos() > r.getSig().getTipoVehiculos())
            {
                NodoS z = r.getSig();
                if(z.getSig() == null)
                {
                    r.setSig(null);
                    z.setSig(r);
                    listaSindicatos.setP(z);
                    z.setAnt(r.getAnt());
                    r.setAnt(z);
                    break;
                }
                else
                {
                    z.getSig().setAnt(r);
                    r.setSig(z.getSig());
                    z.setAnt(r.getAnt());
                    z.setSig(r);
                    r.setAnt(z);
                    listaSindicatos.setP(z);
                    r = z;
                }
            }
            while(r.getSig() != null)
            {

                if(r.getTipoVehiculos() > r.getSig().getTipoVehiculos())
                {
                    NodoS z = r.getSig();
                    if(z.getSig() == null)
                    {

                        r.setSig(null);
                        z.setSig(r);
                        r.getAnt().setSig(z);
                        z.setAnt(r.getAnt());
                        r.setAnt(z);

                    }
                    else
                    {
                        z.getSig().setAnt(r);
                        r.setSig(z.getSig());
                        z.setAnt(r.getAnt());
                        z.setSig(r);
                        r.getAnt().setSig(z);
                        r.setAnt(z);
                    }
                    r = z;
                }
                r = r.getSig();
            }
        }

    }
    public int nroNodos(NodoS r)
    {
        if(r != null)
            return nroNodos(r.getSig()) + 1;
        else
            return 0;
    }

    public void solucion5(View view)
    {
        limpieza(true);
        ordenarListaPorCategoria();

        llenarListaSindicato(listaSindicatos.getP());
    }

    public int gananciasTaxis(MultiPT a, int i)
    {
        if(!a.esVacia(i))
            return gananciasTaxis(a, i + 1) + totalGananciasTaxis(a, new PilaT(), i);
        else
            return 0;
    }
    public int totalGananciasTaxis(MultiPT a, PilaT aux, int i)
    {
        if(!a.esVacia(i))
        {
            Taxi x = a.eliminar(i);
            aux.adicionar(x);
            return totalGananciasTaxis(a, aux, i) + x.getPasaje();
        }
        else
        {
            a.vaciar(i, aux);
            return 0;
        }
    }
    public int gananciasRadioTaxis(MultiCRT a, int i)
    {
        if(!a.esVacia(i))
            return gananciasRadioTaxis(a, i + 1) + totalGananciasRadioTaxis(a, new CSimpleRT(), i);
        else
            return 0;
    }
    public int totalGananciasRadioTaxis(MultiCRT a, CSimpleRT aux, int i)
    {
        if(!a.esVacia(i))
        {
            RadioTaxi x = a.eliminar(i);
            aux.adicionar(x);
            return totalGananciasRadioTaxis(a, aux, i) + x.getPasaje();
        }
        else
        {
            a.vaciar(i, aux);
            return 0;
        }
    }

    public void solucion4(View view)
    {
        Switch switchTaxi = findViewById(R.id.switch1);
        Switch switchRadioTaxi = findViewById(R.id.switch2);
        String out = "";
        if(switchTaxi.isChecked())
            out = "Las ganancias totales de los taxis en hoteles u empresas es de: " + gananciasTaxis(multiTaxis, 0);
        if(switchRadioTaxi.isChecked())
            out = "Las Ganacias totales de los radio taxis en hoteles u empresas es de: " + gananciasRadioTaxis(multiRadioTaxis, 0);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Ganacias totales: ");
        builder.setMessage(out);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    //llenado de datos
    public void llenarDatos()
    {
        LDCircularOD l1 = new LDCircularOD();
        l1.adicionar("Satelite", "San Pedro", 3);
        l1.adicionar("Ceja", "Satelite", 2);
        l1.adicionar("El prado", "Cota cota", 3);
        l1.adicionar("Sopocachi", "San Pedro", 1);

        LDCircularOD l2 = new LDCircularOD();
        l2.adicionar("Satelite", "San Pedro", 3);
        l2.adicionar("Ceja", "Satelite", 2);
        l2.adicionar("El prado", "Cota cota", 3);
        l2.adicionar("Sopocachi", "San Pedro", 1);

        LDCircularOD l3 = new LDCircularOD();
        l3.adicionar("Satelite", "San Pedro", 3);
        l3.adicionar("Ceja", "Satelite", 2);


        LDCircularOD l4 = new LDCircularOD();
        l4.adicionar("Satelite", "San Pedro", 3);
        l4.adicionar("Ceja", "Satelite", 2);
        l4.adicionar("El prado", "Cota cota", 3);

        LDCircularOD l5 = new LDCircularOD();
        l5.adicionar("Satelite", "San Pedro", 3);
        l5.adicionar("Ceja", "Satelite", 2);
        l5.adicionar("El prado", "Cota cota", 3);

        LDCircularOD l6 = new LDCircularOD();
        l6.adicionar("Satelite", "San Pedro", 3);
        l6.adicionar("Ceja", "Satelite", 2);
        l6.adicionar("El prado", "Cota cota", 3);
        l6.adicionar("Sopocachi", "San Pedro", 1);

        listaSindicatos.adicionar("Sindicato_1", 1, l1);
        listaSindicatos.adicionar("Sindicato_2", 2, l2);
        listaSindicatos.adicionar("Sindicato_3", 3, l3);
        listaSindicatos.adicionar("Sindicato_4", 2, l4);
        listaSindicatos.adicionar("Sindicato_5", 2, l5);
        listaSindicatos.adicionar("Sindicato_6", 3, l6);

        multiTrufis.adicionar(0, new Trufi("Toyota", "ABCD1234", 2003));
        multiTrufis.adicionar(0, new Trufi("Suzuki", "BCDA6834", 2002));
        multiTrufis.adicionar(0, new Trufi("Toyota", "RHRW6553", 2002));
        multiTrufis.adicionar(0, new Trufi("Toyota", "TUWW3421", 2001));

        multiMiniBuses.adicionar(0, new Minibus("Toyota", "WYSS6352", 2000));
        multiMiniBuses.adicionar(0, new Minibus("Toyota", "CBCS4753", 2001));

        multiMiniBuses.adicionar(1, new Minibus("Toyota", "WFWE7846", 2001));
        multiMiniBuses.adicionar(1, new Minibus("Toyota", "HRBE5863", 2002));

        multiMiniBuses.adicionar(2, new Minibus("Toyota", "RBHW7846", 2001));
        multiMiniBuses.adicionar(2, new Minibus("Toyota", "VBVS5863", 2002));

        multiMicros.adicionar(0, new Micro("GMC", "VBVS2654", 2001));
        multiMicros.adicionar(0, new Micro("GMC", "FVGE2654", 2002));
        multiMicros.adicionar(0, new Micro("Mercedez", "DTWF2654", 2000));

        multiMicros.adicionar(1, new Micro("GMC", "TJWG2654", 2005));
        multiMicros.adicionar(1, new Micro("GMC", "BCVZ2654", 2002));

        listaEmpHot.adicionar("Empresa_1", 1);
        listaEmpHot.adicionar("Empresa_2", 2);
        listaEmpHot.adicionar("Hotel_1", 2);
        listaEmpHot.adicionar("Hotel_2", 1);

        multiTaxis.adicionar(0, new Taxi("Toyota", "ABCV3764", 2003, "Sopocachi", "Cota cota", 20));
        multiTaxis.adicionar(0, new Taxi("Toyota", "ABCV3764", 2003, "Zona sur", "Cota cota", 15));

        multiTaxis.adicionar(1, new Taxi("Toyota", "ABCV3764", 2003, "Sopocachi", "El Prado", 19));
        multiTaxis.adicionar(1, new Taxi("Toyota", "ABCV3764", 2003, "Cota cota", "Zona sur", 28));

        multiRadioTaxis.adicionar(0, new RadioTaxi("Toyota", "ABCV3764", 2003, "Sopocachi", "Satelite", 30));
        multiRadioTaxis.adicionar(0, new RadioTaxi("Toyota", "REJW3764", 2003, "Sopocachi", "San Pedro", 12));
        multiRadioTaxis.adicionar(0, new RadioTaxi("Toyota", "EHD4243", 2003, "San Padro", "Satelite", 12));
        multiRadioTaxis.adicionar(0, new RadioTaxi("Toyota", "FGSV8957", 2003, "Satelite", "San Pedro", 30));

        multiRadioTaxis.adicionar(1, new RadioTaxi("Toyota", "ABCV3764", 2003, "Satelite", "Ingavi", 10));
        multiRadioTaxis.adicionar(1, new RadioTaxi("Toyota", "ERHS3764", 2003, "Satelite", "ingavi", 10));

        llenarListaSindicato(listaSindicatos.getP());
        llenarListaEmpHot(listaEmpHot.getP());



    }
}
