package com.example.proyecto_lab_131;

import java.io.Serializable;

public class CCircularM implements Serializable
{
    private int ini, fin, max = 50;
    private Micro v[] = new Micro[max + 1];

    CCircularM()
    {
        ini = fin = 0;
    }

    public boolean esVacia()
    {
        return (max - ini + fin) % max == 0;
    }
    public boolean esLlena()
    {
        return (max - ini + fin) % max == max;
    }
    public int nroElementos()
    {
        return (max - ini + fin) % max;
    }

    public void adicionar(Micro x)
    {
        if(!esLlena())
        {
            fin = (fin + 1) % max;
            v[fin] = x;
        }
    }
    public Micro eliminar()
    {
        Micro x = new Micro("", "", -1);

        if(!esVacia())
        {
            ini = (ini + 1) % max;
            x = v[ini];
            if(ini == fin)
            {
                ini = fin = 0;
            }
        }

        return x;
    }

    public void vaciar(CCircularM Z)
    {
        if(!Z.esVacia())
        {
            adicionar(Z.eliminar());
            vaciar(Z);
        }
    }
}
